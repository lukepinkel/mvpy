#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 17:51:07 2019

@author: lukepinkel
"""

